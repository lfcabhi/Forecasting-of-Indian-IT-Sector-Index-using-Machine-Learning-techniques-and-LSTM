
library(mboost)
IT_data <- read.csv("E:/Univariate_N5/Train_norm.csv")
IT_test <- read.csv("E:/Univariate_N5/Test_norm.csv")
set.seed(300)

head(IT_data)
head(IT_test)


myadaboost <- blackboost(close_norm ~ ., data=IT_data)

summary(myadaboost)

close_pred <- predict(myadaboost, IT_test)

head(close_pred)

plot(IT_test$close_norm, xlab="Time points", ylab="Percentage Change in Closed Values",lty=1, col = "red", type = 'l', lwd = 2, ylim = c(-0.06, 0.05))
lines(close_pred, lty=2, col = "blue", lwd=2)
legend("topright", c("Actual Index","Predicted Index"), col=c("red","blue"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

y <- (IT_test$close_norm - close_pred)
plot(y, xlab = "Time Points", ylab = "Residual Values", lwd = 1.5)

plot(IT_test$close_norm~close_pred,  xlab = "Predicted Index", ylab = "Actual Index", lwd = 2)

cor(IT_test$close_norm, close_pred)
library(Metrics)

x <- rmse(IT_test$close_norm, close_pred)
x
y <- mean(abs(IT_test$close_norm))
y
z <- (x/y)*100
z

w <- IT_test$close_norm * close_pred
m <- which(w < 0)
m
mismatch<-length(m)
mismatch
len <- length(IT_test$close_norm)
len
#length(IT_test$close_norm)
m_perc <- ((mismatch/len)*100)
m_perc


