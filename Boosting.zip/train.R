
library(mboost)
IT_data <- read.csv("E:/Univariate_N5/Train_norm.csv")

head(IT_data)
set.seed(300)

myadaboost <- blackboost(close_norm ~ ., data=IT_data)

close_pred <- predict(myadaboost, IT_data)
head(close_pred)

plot(IT_data$close_norm, xlab="Time points", ylab="Percmentage change in closed value",lty=1, col = "red", type = 'l', lwd = 2, xlim = c(0,2650),  ylim = c(-0.14, 0.14))
lines(close_pred, lty=2, col = "blue", lwd=2)
legend("topright", c("Actual Index","Predicted Index"), col=c("red","blue"), cex=0.65, lty=c(1,2), lwd=c(2,2), bty="n")

y <- (IT_data$close_norm - close_pred)
head(y)
plot(y, xlab = "Time Points", ylab = "Residual Values", lwd = 1.5)
cor(IT_data$close_norm, close_pred)
library(Metrics)

plot(IT_data$close_norm~close_pred,  xlab = "Predicted Index", ylab = "Actual Index", lwd = 2)

x <- rmse(IT_data$close_norm, close_pred)
x
y <- mean(abs(IT_data$close_norm))
y
z <- (x/y)*100
z

w <- IT_data$close_norm * close_pred
m <- which(w < 0)
m
mismatch<-length(m)
mismatch
m_norm <- (mismatch/length(IT_data$close_norm)*100)
m_norm

