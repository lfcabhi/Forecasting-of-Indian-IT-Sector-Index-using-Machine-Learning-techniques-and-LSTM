

library(earth)
library(dplyr)
library(caret)
library(ggplot2)
IT_data <- read.csv("E:/Univariate_N5/Train_norm.csv")
head(IT_data)
attach(IT_data)

#grid search for finding the optimized parameters
hyper_grid <- expand.grid(
  degree = 1:3, 
  nprune = seq(2, 100, length.out = 10) %>% floor()
)
head(hyper_grid)
set.seed(123)

tuned_mars <- train(
  x = subset(IT_data, select = -close_norm),
  y = IT_data$close_norm,
  method = "earth",
  metric = "RMSE",
  trControl = trainControl(method = "cv", number = 10),
  tuneGrid = hyper_grid
)
library(vip)
tuned_mars$bestTune
ggplot(tuned_mars , size=2)
p1 <- vip(tuned_mars, num_features = 23, bar = FALSE, value = "gcv") + ggtitle("GCV")
p2 <- vip(tuned_mars, num_features = 23, bar = FALSE, value = "rss") + ggtitle("RSS")
gridExtra::grid.arrange(p1, p2, ncol = 2)


earth_reg <- earth(close_norm~., data = na.omit (IT_data, trace=1), nprune = 23, degree = 2)
earth_reg
summary(earth_reg)

x <- predict(earth_reg, IT_data)
length(x)

cor(IT_data$close_norm, x)

y <- IT_data$close_norm
z <- x*y
mism<-which(z < 0)
length(mism)
mis_case<-(length(mism)/length(x)*100)

mis_case
library(Metrics)
a <- rmse(x,y)
a
b <- mean(abs(y))
b

w <- (a/b)*100
w

plot(y, xlab="Time points", ylab="Percentage change in Close values", lwd=2, lty=1, col="red", type='l')
lines(x, lty=2, col="blue", lwd=2)
legend("topright", c("Actual Index","Predicted Index"), col=c("red","blue"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

plot(y~x, xlab = "Predicted Index", ylab = "Actual Index", lwd = 2)

plot(earth_reg$residuals, xlab = "Time points", ylab = "Residual values", lwd = 1)
