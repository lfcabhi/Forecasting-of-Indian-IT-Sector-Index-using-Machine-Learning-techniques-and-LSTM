
# install.packages("earth")
library(earth)
IT_data <- read.csv("E:/Univariate_N5/Train_norm.csv")

IT_test <- read.csv("E:/Univariate_N5/Test_norm.csv")

attach(IT_data)
mars_reg <- earth(IT_data$close_norm~., data = na.omit (IT_data), trace=1,nprune = 23, degree = 2)

summary(mars_reg)
x <- predict(mars_reg, newdata=IT_test)
length(x)

cor(IT_test$close_norm, x)

y <- IT_test$close_norm
z <- x*y
mism<-which(z < 0)
length(mism)
mis_case<-(length(mism)/length(x)*100)

mis_case

library(Metrics)
a <- rmse(x,y)
a
b <- mean(abs(y))
b
w <- (a/b)*100
w

plot(y, xlab="Time points", ylab="Percentage change in Close values", lwd=2, lty=1, col="red", type='l', ylim = c(-0.06,0.06))
lines(x, lty=2, col="blue", lwd=2)
legend("topright", c("Actual Index","Predicted Index"), col=c("red","blue"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

plot(y~x, xlab = "Predicted Index", ylab = "Actual Index", lwd = 2)

v = (y - x)

plot(v, xlab = "Time points", ylab = "Residual values", lwd = 1)
