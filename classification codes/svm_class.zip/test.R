
# install.packages("kernlab")
library(kernlab)
IT_data <- read.csv("E:/Univariate_N5/Train_norm_class.csv")
IT_test <- read.csv("E:/Univariate_N5/Test_norm_class.csv")
#IT_data$close_norm <- factor(IT_data$close_norm)
IT_test$close_norm


set.seed(300)
attach(IT_test)
close_classifier <- ksvm(close_norm~., data= IT_data, kernel="vanilladot")
close_classifier
close_pred <- predict(close_classifier, IT_test)
head(close_pred)
length(close_pred)
plot(IT_test$close_norm~close_pred, xlab = "Predicted percentage change in close values", ylab = "Actual percentage change in close values", lwd = 1)

gg1=floor(close_pred+0.5)
gg1[231]
length(gg1)
c=0
for (i in 1:length(gg1)){
  if(gg1[i]<0){
    c=c+1
    gg1[i]=0}
  else if (gg1[i]>1)
    gg1[i]=1
  c=c+1
}
c
gg1
ttt <- table(IT_test$close_norm, gg1)
ttt
error <- (ttt[1,2]+ttt[2,1])/259
error


