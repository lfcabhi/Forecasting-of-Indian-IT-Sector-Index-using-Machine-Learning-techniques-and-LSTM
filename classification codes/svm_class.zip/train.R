
# install.packages("kernlab")
library(kernlab)
IT_data <- read.csv("E:/Univariate_N5/Train_norm_class.csv")
#IT_data$close_norm <- factor(IT_data$close_norm)
IT_data$close_norm


 set.seed(300)
attach(IT_data)
close_classifier <- ksvm(close_norm~., data= IT_data, kernel="vanilladot")
close_classifier
close_pred <- predict(close_classifier, IT_data)
head(close_pred)
plot(IT_data$close_norm~close_pred, xlab = "Predicted percentage change in close values", ylab = "Actual percentage change in close values", lwd = 1)

gg1=floor(close_pred+0.5)
gg1[995]
length(gg1)
c=0
for (i in 1:length(gg1)){
if(gg1[i]<0){
  c=c+1
  gg1[i]=0}
else if (gg1[i]>1)
  gg1[i]=1
  c=c+1
}
c
gg1
ttt <- table(IT_data$close_norm, gg1)
ttt
error <- (ttt[1,2]+ttt[2,1])/2609
error


