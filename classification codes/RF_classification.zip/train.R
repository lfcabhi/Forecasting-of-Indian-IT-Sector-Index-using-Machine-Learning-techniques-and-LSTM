
library(randomForest)
IT_data <- read.csv("E:/Univariate_N5/Train_norm_class.csv")
#IT_data$close_norm <- factor(IT_data$close_norm)
IT_data$close_norm
set.seed(300)
attach(IT_data)
myrf <- randomForest(close_norm~., data= IT_data)
myrf
close_pred <- predict(myrf, IT_data)
length(close_pred)

gg1=floor((as.numeric(as.character(close_pred))) + 0.5)
gg1

ttt <- table(IT_data$close_norm,gg1)
ttt

error <- (ttt[1,2]+ttt[2,1])/2609
error
plot(IT_data$close_norm~close_pred, xlab = "Predicted percentage change in close values", ylab = "Actual percentage change in close values", lwd = 1)
