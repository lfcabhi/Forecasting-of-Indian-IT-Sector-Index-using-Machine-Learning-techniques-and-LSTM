IT_data <- read.csv("E:/Univariate_N5/Train_norm_class.csv")
head(IT_data)

mymodel <- glm(close_norm~., family=binomial, data= IT_data)
ptest <- predict(mymodel,newdata=data.frame(IT_data),type="response")
ptest
attach(IT_data)
plot(IT_data$close_norm~ptest, ylab="Actual values",xlab="Predicted Close values", lwd=1)
gg1=floor(ptest+0.5)
ttt=table(close_norm,gg1)
ttt
error=(ttt[1,2]+ttt[2,1])/2609
error

x <- (gg1 - close_norm)
m<-which(x==1 | x==-1)
length(m)


# Computation of Lift
data.frame(IT_data$close_norm, ptest)
bb <- cbind(ptest, IT_data$close_norm)
bb[1:10,]
bb1 <- bb[order(ptest, decreasing = TRUE),]
bb1[1:10,]
xbar <- mean(IT_data$close_norm)
axis <- 2609
ax <- 2609
ay <- 2609
axis[1] = 1
ax[1] = xbar
ay[1] <- bb1[1, 2]
for( i in 2:2609){
  axis[i] = i
  ax[i] = xbar*i
  ay[i] = ay[i-1]+ bb1[i,2]
}
aaa <- cbind(bb1[,1], bb1[,2], ay, ax)
plot(axis, ay, xlab="Number of Time Slots", ylab="Number of Time Slots with Gain")
points(axis,ax,type="l")

library(ROCR)
ROCRpred <- prediction(ptest, IT_data$close_norm)
ROCRperf <- performance(ROCRpred, 'tpr','fpr')
plot(ROCRperf, colorize = TRUE, text.adj = c(-0.2,1.7), lwd = 4)

library(pROC)
roc_obj <- roc(IT_data$close_norm, ptest)
auc(roc_obj) 
