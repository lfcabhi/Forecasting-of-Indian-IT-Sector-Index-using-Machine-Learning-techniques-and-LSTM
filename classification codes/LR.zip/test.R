IT_data <- read.csv("E:/Univariate_N5/Train_norm_class.csv")
IT_data_logit <- glm(close_norm~., family=binomial, data= IT_data)
IT_test <- read.csv("E:/Univariate_N5/Test_norm_class.csv")
ptest<- predict(IT_data_logit,newdata=data.frame(IT_test),type="response")
length(ptest)
attach(IT_test)
plot(IT_test$close_norm~ptest, ylab="Actual values",xlab="Predicted Close values", lwd=1)
gg1=floor(ptest+0.5)
ttt=table(close_norm,gg1)
ttt
error=(ttt[1,2]+ttt[2,1])/259
error

x <- (gg1 - close_norm)
m<-which(x==1 | x==-1)
length(m)


# Computation of Lift
data.frame(IT_test$close_norm, ptest)
bb <- cbind(ptest, IT_test$close_norm)
bb[1:10,]
bb1 <- bb[order(ptest, decreasing = TRUE),]
bb1[1:10,]
xbar <- mean(IT_test$close_norm)
axis <- 259
ax <- 259
ay <- 259
axis[1] = 1
ax[1] = xbar
ay[1] <- bb1[1, 2]
for( i in 2:259){
  axis[i] = i
  ax[i] = xbar*i
  ay[i] = ay[i-1]+ bb1[i,2]
}
aaa <- cbind(bb1[,1], bb1[,2], ay, ax)
plot(axis, ay, xlab="Number of Time Slots", ylab="Number of Time Slots with Gain")
points(axis,ax,type="l")

library(ROCR)
ROCRpred <- prediction(ptest, IT_test$close_norm)
ROCRperf <- performance(ROCRpred, 'tpr','fpr')
plot(ROCRperf, colorize = TRUE, text.adj = c(-0.2,1.7), lwd = 4)

library(pROC)
roc_obj <- roc(IT_test$close_norm, ptest)
auc(roc_obj)

