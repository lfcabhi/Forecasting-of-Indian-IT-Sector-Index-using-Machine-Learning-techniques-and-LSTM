
library(ipred)
IT_Test <- read.csv("E:/Univariate_N5/Test_norm_class.csv")
IT_Train <- read.csv("E:/Univariate_N5/Train_norm_class.csv")
set.seed(300)
mybag <- bagging(close_norm~., data=IT_Train, nbag=25)
close_pred <- predict(mybag, IT_Test)
close_pred
attach(IT_Test)
plot(IT_Test$close_norm~close_pred, xlab = "Predicted percenatge change in close value", ylab = "actual percentage change in close value", lwd = 1)
gg1=floor(close_pred+0.5)
gg1
length(close_norm)
length(close_pred)
ttt <- table(close_norm,gg1)
ttt
length(gg1)
error <- (ttt[1,2]+ttt[2,1])/259
error
# for identifying the wrongly predicted records
x <- (gg1 - close_norm)
m<-which(x== 1 | x== -1)
length(m)

