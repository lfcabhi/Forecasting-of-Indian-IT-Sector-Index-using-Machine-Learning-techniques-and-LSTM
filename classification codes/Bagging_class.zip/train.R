
library(ipred)
IT_data <- read.csv("E:/Univariate_N5/Train_norm_class.csv")
set.seed(300)

mybag <- bagging(close_norm~.-close_norm, data=IT_data, nbag=25)
close_pred <- predict(mybag, IT_data)
length(close_pred)
head(close_pred)
attach(IT_data)
plot(IT_data$close_norm~close_pred, xlab = "Predicted percentage change in close values", ylab = "Actual percentage change in close values", lwd = 1)
gg1=floor(close_pred+0.5)
gg1

length(close_norm)
length(close_pred)
ttt <- table(close_norm,gg1)
ttt
length(gg1)


error <- (ttt[1,2]+ttt[2,1])/2609
error
# for identifying the wronly predicted records
x <- (gg1 - close_norm)
m<-which(x==1 | x==-1)
length(m)
