
IT_data <- read.csv("E:/Univariate_N5/Train_norm_class.csv")
IT_test <- read.csv("E:/Univariate_N5/Test_norm_class.csv")

str(IT_data)
str(IT_test)
normalize <- function(x){return((x-min(x))/(max(x)-min(x)))
}
IT_data_norm <- as.data.frame(lapply(IT_data, normalize))
IT_test_norm <- as.data.frame(lapply(IT_test, normalize))
summary(IT_data_norm$close_norm)
summary(IT_test_norm$close_norm)
library(neuralnet)
head(IT_test_norm)

set.seed(300)
IT_data_model <- neuralnet(close_norm ~ ., data = IT_data_norm,hidden = 3, linear.output=FALSE, stepmax = 1e06)
plot(IT_data_model)
model_results <- compute(IT_data_model, IT_test_norm[c(1:7)])
predicted_norm <- model_results$net.result
predicted_norm 
plot(IT_test_norm$close_norm~predicted_norm, xlab = "Predicted normentage change in Open value", ylab = "Actual normentage change in Open value", lwd = 2)
gg <- floor(predicted_norm + 0.5)
gg
ttt <- table(IT_test_norm$close_norm, gg)
ttt
plot(IT_test_norm$close_norm~predicted_norm)
error <- 100*(ttt[1,2] +ttt[2,1])/725
error

z <- abs(IT_test_norm$close_norm - gg)
which(z > 0)
