IT_data <- read.csv("E:/Univariate_N5/Train_norm_class.csv")
str(IT_data)

normalize <- function(x){return((x-min(x))/(max(x)-min(x)))
  }
IT_data_norm <- as.data.frame(lapply(IT_data, normalize))
summary(IT_data_norm$close_norm)
library(neuralnet)
head(IT_data_norm)
set.seed(300)
IT_data_model <- neuralnet(close_norm ~., data = IT_data_norm, hidden = 2,linear.output = TRUE, stepmax = 1e06)
plot(IT_data_model)
model_results <- compute(IT_data_model, IT_data_norm[c(1:7)])
predicted_norm <- model_results$net.result
plot(IT_data_norm$close_norm~predicted_norm, xlab = "Predicted percentage change in close values", ylab = "Actual percentage change in close values", lwd = 1)
gg <- floor(predicted_norm + 0.5)
gg
ttt=table(IT_data$close_norm,gg)
ttt
error=(ttt[1,2]+ttt[2,1])/745
error
z <- abs(IT_data$close_norm - gg)
x<-which(z > 0)
length(x)

mismatch_perc = (length(x)/2609)*100
mismatch_perc
