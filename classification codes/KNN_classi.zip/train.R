
IT_data <- read.csv("E:/Univariate_N5/Train_norm_class.csv")
str(IT_data)
table(IT_data$close_norm)
normalize <- function(x) {return ((x-min(x))/(max(x)-min(x)))}
IT_data_n <- as.data.frame(lapply(IT_data, normalize))
library(class)
IT_data_train <- IT_data_n[1:2609,-8]
IT_data_test <- IT_data_n[1:2609,-8]
IT_data_train_labels <- IT_data[1:2609,8]
IT_data_test_labels <- IT_data[1:2609,8]
IT_data_test_pred_1 <- knn(train=IT_data_train, test = IT_data_test, cl= IT_data_train_labels, k=1)
IT_data_test_pred_3 <- knn(train=IT_data_train, test = IT_data_test, cl= IT_data_train_labels, k=3)
IT_data_test_pred_5 <- knn(train=IT_data_train, test = IT_data_test, cl= IT_data_train_labels, k=5)
IT_data_test_pred_7 <- knn(train=IT_data_train, test = IT_data_test, cl= IT_data_train_labels, k=7)
IT_data_test_pred_9 <- knn(train=IT_data_train, test = IT_data_test, cl= IT_data_train_labels, k=9)

nearest1 <- knn(train=IT_data_train, test=IT_data_test, cl=IT_data_train_labels, k=1)
nearest1

nearest3 <- knn(train=IT_data_train, test=IT_data_test, cl=IT_data_train_labels, k=3)
nearest3

nearest5 <- knn(train=IT_data_train, test=IT_data_test, cl=IT_data_train_labels, k=5)
nearest5

nearest7 <- knn(train=IT_data_train, test=IT_data_test, cl=IT_data_train_labels, k=7)
nearest7

nearest9 <- knn(train=IT_data_train, test=IT_data_test, cl=IT_data_train_labels, k=9)
nearest9

error1 <- 100*sum(IT_data_test_labels==nearest1)/2609
error1

error3 <- 100*sum(IT_data_test_labels==nearest3)/2609
error3

error5 <- 100*sum(IT_data_test_labels==nearest5)/2609
error5

error7 <- 100*sum(IT_data_test_labels==nearest7)/2609
error7

error9 <- 100*sum(IT_data_test_labels==nearest9)/2609
error9


#install.packages("gmodels")
library(gmodels)
CrossTable(x=IT_data_test_labels, y = IT_data_test_pred_1, prop.chisq=FALSE)
CrossTable(x=IT_data_test_labels, y = IT_data_test_pred_3, prop.chisq=FALSE)
CrossTable(x=IT_data_test_labels, y = IT_data_test_pred_5, prop.chisq=FALSE)
CrossTable(x=IT_data_test_labels, y = IT_data_test_pred_7, prop.chisq=FALSE)
CrossTable(x=IT_data_test_labels, y = IT_data_test_pred_9, prop.chisq=FALSE)

plot(IT_data_train_labels~IT_data_test_pred_3, xlab = "Predicted percentage change in close values", ylab = "Actual percentage change in close values", lwd = 2)
length(IT_data_test_pred_3)
IT_data_test_pred_3
