# install.packages("e1071")
library(e1071)
IT_data <- read.csv("E:/Univariate_N5/Train_norm.csv")

IT_test <- read.csv("E:/Univariate_N5/Test_norm.csv")

attach(IT_data)
IT_data_reg <- svm(close_norm ~ ., data = IT_data, scale = TRUE)
IT_data_reg
close_pred <- predict(IT_data_reg, IT_test)
close_pred

plot(IT_test$close_norm, xlab="Time points", ylab="Percentage change in Close Values",lty=1, col = "red", type = 'l', lwd = 2, ylim = c(-0.06, 0.06))
lines(close_pred, lty=2, col = "blue", lwd=2)
legend("topright", c("Actual Index","Predicted Index"), col=c("red","blue"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

y <- (IT_test$close_norm - close_pred)
plot(y, xlab = "Time points", ylab = "Residual values", lwd = 1)
cor(IT_test$close_norm, close_pred)
attach(IT_test)
plot(IT_test$close_norm~close_pred, xlab = "Predicted Index", ylab = "Actual Index", lwd = 2)
library(Metrics)
x <- rmse(IT_test$close_norm, close_pred)
x
y <- mean(abs(IT_test$close_norm))
y
z <- (x/y)*100
z

w <- IT_test$close_norm * close_pred
m <- which(w < 0)
m
mismatch<-length(m)
mismatch
m_norm <- (mismatch/length(IT_test$close_norm)*100)
m_norm
