
library(tree)
IT_data <- read.csv("E:/Univariate_N5/Train_norm.csv")
IT_data_tree <- tree(close_norm~., data=IT_data, mincut=1)
plot(IT_data_tree, lwd=2)
text(IT_data_tree, digits=2)
x <- predict(IT_data_tree, data=IT_data)
x
y <- IT_data$close_norm
y

max(y)
min(y)
plot(y, xlab="Time points", ylab="Percentage change in Close values",lty=1, col = "red", type = 'l', lwd = 2, ylim = c(-0.15, 0.15))
lines(x, lty=2, col = "blue", lwd=2)
legend("topright", c("Actual Index","Predicted Index"), col=c("red","blue"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")


cor(x,y)
s <- (y - x)
plot(s, xlab = "Time points", ylab = "Residual values", lwd = 1)
plot(IT_data$close_norm~x,  xlab = "Predicted Index", ylab = "Actual Index", lwd = 2)

library(Metrics)
z <- rmse(x,y)
z
w <- mean(abs(IT_data$close_norm))
w
(z/w)*100

w <- IT_data$close_norm*x

m <- which (w < 0)
m
length(m)
mismatch<-length(m)
mismatch
mis<-length(IT_data$close_norm)
mis
m_norm <- ((mismatch/mis)*100)
m_norm
