
library(tree)
IT_data <- read.csv("E:/Univariate_N5/Train_norm.csv")
IT_test <- read.csv("E:/Univariate_N5/Test_norm.csv")
head(IT_data$close_norm)
IT_data_tree <- tree(close_norm~., data=IT_data, mincut=1)
plot(IT_data_tree, lwd=2)
text(IT_data_tree, digits=2)
x <- predict(IT_data_tree, data=IT_test)
head(x)
length(x)
x <- x[1:259]
y <- IT_test$close_norm
length(x)
cor(x,y)

max(x)
min(x)
plot(y, xlab="Time points", ylab="Percentage change in closed values",lty=1, col = "red", type = 'l', lwd = 2, ylim = c(-0.09, 0.09))
lines(x, lty=2, col = "blue", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("red","blue"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

m <- (y - x)
m
plot(m, xlab = "Time points", ylab = "Residual values", lwd = 1)
plot(x~y,  xlab = "Predicted Index", ylab = "Actual Index", lwd = 2)

cor(x,y)

library(Metrics)
z <- rmse(x,y)
z
w <- mean(abs(IT_test$close_norm))
w
metr<-(z/w)*100
metr

w <- IT_test$close_norm*x

m <- which (w < 0)
m
length(m)
mismatch<-length(m)
mismatch
mis<-length(IT_test$close_norm)
mis
m_norm <- ((mismatch/mis)*100)
m_norm
