IT_data <- read.csv("E:/Univariate_N5/Train_norm.csv")
head(IT_data)
IT_test <- read.csv("E:/Univariate_N5/Test_norm.csv")

str(IT_data)
str(IT_test)
set.seed(300)
normalize <- function(x){return((x-min(x))/(max(x)-min(x)))
}
IT_data_norm <- as.data.frame(lapply(IT_data, normalize))
IT_test_norm <- as.data.frame(lapply(IT_test, normalize))
summary(IT_data_norm$close_norm)
summary(IT_test_norm$close_norm)
naprint(IT_data_norm)
naprint(IT_test_norm)
library(neuralnet)
head(IT_test_norm)

IT_data_model <- neuralnet(close_norm ~.-year,hidden = 2,data = IT_data_norm)
plot(IT_data_model)
model_results <- compute(IT_data_model, IT_test_norm)
head(model_results)
predicted_close_norm <- model_results$net.result
predicted_close <- predicted_close_norm*(max(IT_test$close_norm) - min(IT_test$close_norm)) + min(IT_test$close_norm)
predicted_close

plot(IT_test$close_norm, xlab="Time points", ylab="Percentage change in Close value",lty=1, col = "red", type = 'l', lwd = 2, ylim = c(-0.05,0.05))
lines(predicted_close, lty=2, col = "blue", lwd=2)
legend("topright", c("Actual Index","Predicted Index"), col=c("red","blue"), cex=1, lty=c(1,2), lwd=c(2,2), bty="n")

cor(predicted_close, IT_test$close_norm)
plot(IT_test$close_norm~predicted_close, xlab = "Predicted Index", ylab = "Actual Index", lwd = 2)

library(Metrics)
 x<- rmse(predicted_close, IT_test$close_norm)
 x
 y <- mean(abs(IT_test$close_norm))
 y
 (x/y)*100
 

 w <- IT_test$close_norm*predicted_close
 
 m <- which (w < 0)
 m
 length(m)
 mismatch<-length(m)
 mismatch
 mis<-length(IT_test$close_norm)
 mis
 m_norm <- ((mismatch/mis)*100)
 m_norm
 
 
 r <- (IT_test$close_norm - predicted_close)
 r
 #max(r)
 plot(r, xlab = "Time points", ylab = "Residual Values", lwd = 1)
 
 