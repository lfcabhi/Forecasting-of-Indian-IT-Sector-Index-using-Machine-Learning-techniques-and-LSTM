
library(ipred)

IT_data <- read.csv("E:/Univariate_N5/Train_norm.csv")
IT_test <- read.csv("E:/Univariate_N5/Test_norm.csv")

set.seed(300)
mybag <- bagging(close_norm~., data=IT_data, nbag=100)
close_pred <- predict(mybag, IT_test)
close_pred

max(close_pred)
min(close_pred)


plot(IT_test$close_norm, xlab="Time points", ylab="Percentage change in close value",lty=1, col = "red", type = 'l', lwd = 2, ylim = c(-0.05, 0.05))
lines(close_pred, lty=2, col = "blue", lwd=2)
legend("topright", c("Actual Index","Predicted Index"), col=c("red","blue"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")
plot(IT_test$close_norm~close_pred,  xlab = "Predicted Index", ylab = "Actual Index", lwd = 2)

y <- (IT_test$close_norm - close_pred)
plot(y, xlab = "Time points", ylab = "Residual values", lwd = 2)
cor(IT_test$close_norm, close_pred)
library(Metrics)
x <- rmse(IT_test$close_norm, close_pred)
x
y <- mean(abs(IT_test$close_norm))
y
z <- (x/y)*100
z

w <- IT_data$close_norm * close_pred
m <- which(w < 0)
m
mismatch<-length(m)
mismatch
m_norm <- (mismatch/length(IT_data$close_norm)*100)
m_norm
