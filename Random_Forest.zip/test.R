# install.packages("randomForest")
library(randomForest)
IT_data <- read.csv("E:/Univariate_N5/Train_norm.csv")
IT_test <- read.csv("E:/Univariate_N5/Test_norm.csv")
head(IT_data)

head(IT_test)

set.seed(300)

myrf <- randomForest(close_norm~., data = IT_data)
myrf
close_pred <- predict(myrf, IT_test)
head(close_pred)

plot(IT_test$close_norm, xlab="Time Points", ylab="Percentage change in Closed Values ", lwd=2, lty=1, col="red", type='l', ylim = c(-0.06,0.06))
lines(close_pred, lty=2, col="blue", lwd=2)
legend("topright", c("Actual Index","Predicted Index"), col=c("red","blue"), cex=0.85, lty=c(1,2), lwd=c(2,2), bty="n")

r <- (IT_test$close_norm - close_pred)
r
max(r)
plot(r, xlab = "Time points", ylab = "Residual Values", lwd = 2)

plot(IT_test$close_norm~close_pred,  xlab = "Predicted Index", ylab = "Actual Index", lwd = 2)

cor(IT_test$close_norm , close_pred)
library(Metrics)
x <- rmse(IT_test$close_norm , close_pred)
x
y <- mean(abs(IT_test$close_norm))
y
z <- (x/y)*100
z

w <- IT_test$close_norm*close_pred

m <- which (w < 0)
m
length(m)
mismatch<-length(m)
mismatch
mis<-length(IT_test$close_norm)
mis
m_norm <- ((mismatch/mis)*100)
m_norm
