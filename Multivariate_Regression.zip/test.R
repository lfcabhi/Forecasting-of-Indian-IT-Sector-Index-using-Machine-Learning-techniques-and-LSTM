
##############################################
#   Backward Removal Procedure               #
##############################################

IT_data <- read.csv("E:/Univariate_N5/Train_norm.csv")
IT_test <- read.csv("E:/Univariate_N5/Test_norm.csv")
head(IT_test)
library(faraway)
IT_data.lm <- lm(close_norm ~. ,data = IT_data)

summary(IT_data.lm)

vif(IT_data.lm)

formula(IT_data.lm)
drop1(IT_data.lm,test='F')


IT_data.lm <- lm(close_norm~day+Day_week+year+open_norm+high_norm+low_norm, data=IT_data)
formula(IT_data.lm)
drop1(IT_data.lm, test='F')


IT_data.lm <- lm(close_norm~day+year+open_norm+high_norm+low_norm, data=IT_data)
drop1(IT_data.lm, test='F')


IT_data.lm <- lm(close_norm~day+open_norm+high_norm+low_norm, data=IT_data)
formula(IT_data.lm)
drop1(IT_data.lm, test='F')


IT_data.lm <- lm(close_norm~open_norm+high_norm+low_norm, data=IT_data)
formula(IT_data.lm)
drop1(IT_data.lm, test='F')


# No further predictors can be dropped, since both are significant.
summary(IT_data.lm)

max(IT_data.lm$residuals)
min(IT_data.lm$residuals)
head(IT_data.lm$fitted.values)
IT_test_lm<-predict(IT_data.lm, IT_test)
length(IT_test_lm)

length(IT_test$close_norm)

plot(IT_test$close_norm, xlab="Time Points", ylab="Percentage change in Closed Values ", lwd=2, lty=1, col="red", type='l', ylim = c(-0.06,0.06))
lines(IT_test_lm, lty=2, col="blue", lwd=2)
legend("topright", c("Actual Index","Predicted Index"), col=c("red","blue"), cex=0.85, lty=c(1,2), lwd=c(2,2), bty="n")


r <- (IT_test$close_norm - IT_test_lm)
r
plot(r, xlab = "Time points", ylab = "Residual Values", lwd = 1)
plot(IT_test$close_norm~IT_test_lm,  xlab = "Predicted Index", ylab = "Actual Index", lwd = 2)

cor(IT_test$close_norm,IT_test_lm)
library(Metrics)
x <- rmse(IT_test$close_norm,IT_test_lm)
x
y <- mean(abs(IT_test$close_norm))
y
z <- (x/y)*100
z

#cor(IT_data$close_norm , close_pred)

w <- IT_test$close_norm*IT_test_lm

m <- which (w < 0)
m
length(m)
mismatch<-length(m)
mismatch
mis<-length(IT_test$close_norm)
mis
m_norm <- ((mismatch/mis)*100)
m_norm

#length(IT_data.lm$residuals)
