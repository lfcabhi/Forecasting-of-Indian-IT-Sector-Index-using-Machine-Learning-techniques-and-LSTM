##############################################
#   Backward Removal Procedure               #
##############################################

IT_data <- read.csv("E:/Univariate_N5/Train_norm.csv")
head(IT_data)
library(faraway)
IT_data.lm <- lm(close_norm ~. ,data = IT_data)

summary(IT_data.lm)

vif(IT_data.lm)

formula(IT_data.lm)
drop1(IT_data.lm,test='F')
# 'Day' has the lowest AIC(-26713). Hence it is removed.

IT_data.lm <- lm(close_norm~month+Day_week+year+open_norm+high_norm+low_norm, data=IT_data)
formula(IT_data.lm)
drop1(IT_data.lm, test='F')


IT_data.lm <- lm(close_norm~month+year+open_norm+high_norm+low_norm, data=IT_data)
formula(IT_data.lm)
drop1(IT_data.lm, test='F')


IT_data.lm <- lm(close_norm~month+open_norm+high_norm+low_norm, data=IT_data)
formula(IT_data.lm)
drop1(IT_data.lm, test='F')


IT_data.lm <- lm(close_norm~open_norm+high_norm+low_norm, data=IT_data)
formula(IT_data.lm)
drop1(IT_data.lm, test='F')


# No further predictors can be dropped, since both are significant.
summary(IT_data.lm)

max(IT_data.lm$residuals)
min(IT_data.lm$residuals)
head(IT_data.lm$fitted.values)

plot(IT_data$close_norm, xlab="Time Points", ylab="Percentage change in Closed Values ", lwd=2, lty=1, col="red", type='l', ylim = c(-0.15,0.15))
lines(IT_data.lm$fitted.values, lty=2, col="blue", lwd=2)
legend("topright", c("Actual Index","Predicted Index"), col=c("red","blue"), cex=0.85, lty=c(1,2), lwd=c(2,2), bty="n")

length(IT_data.lm$fitted.values)

r <- (IT_data$close_norm - IT_data.lm$fitted.values)
r
plot(r, xlab = "Time points", ylab = "Residual Values", lwd = 1)
plot(IT_data$close_norm~IT_data.lm$fitted.values,  xlab = "Predicted Index", ylab = "Actual Index", lwd = 2)

cor(IT_data$close_norm,IT_data.lm$fitted.values)
library(Metrics)
x <- rmse(IT_data$close_norm,IT_data.lm$fitted.values)
x
y <- mean(abs(IT_data$close_norm))
y
z <- (x/y)*100
z


w <- IT_data$close_norm*IT_data.lm$fitted.values

m <- which (w < 0)
m
length(m)
mismatch<-length(m)
mismatch
mis<-length(IT_data$close_norm)
mis
m_norm <- ((mismatch/mis)*100)
m_norm


